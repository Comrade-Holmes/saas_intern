
# SaaS Productivity Tool

## Features
- React Frontend
- Node.js + Express Backend
- MongoDB Database
- JWT Authentication
- CRUD Operations for Tasks
- Professional UI

## Setup Instructions

### Backend
```bash
cd backend
npm install
npm start
```

### Frontend
```bash
cd frontend
npm install
npm start
```

## MongoDB
Update `.env` file inside backend folder:

```env
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=supersecretkey
```

Backend runs on:
http://localhost:5000

Frontend runs on:
http://localhost:3000
